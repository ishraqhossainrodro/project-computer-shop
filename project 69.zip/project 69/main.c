/* name : ishraq hossain rodro
id : 2311675042
computer shop management*/



#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct Shop {
    char name[50];
    int quantity;
    float price;
} ;

struct Shop computer[100000];
int totalcomputer=0;

void add_computer() {

    struct Shop new_computer;

    printf("Enter Brand's name: ");
    scanf("%s", new_computer.name);

    printf("Enter quantity: ");
    scanf("%d", &new_computer.quantity);

    printf("Enter price: ");
    scanf("%f", &new_computer.price);

    computer[totalcomputer++] = new_computer;

    printf("Shop added successfully.\n");
}

void display() {
    if (totalcomputer == 0) {
        printf("Inventory is empty.\n");
        return;
    }

    printf("========== Inventory ==========\n");
    printf("Name\t\tQuantity\tPrice\n");

    for (int i = 0; i < totalcomputer; i++) {
        printf("%s\t\t%d\t\t%.2f\n", computer[i].name, computer[i].quantity, computer[i].price);
    }
}

void Sale() {
    if (totalcomputer == 0) {
        printf("Inventory is empty. Cannot make a sale.\n");
        return;
    }

    char ShopName[50];
    int quantity;

    printf("Enter brand's name: ");
    scanf("%s", ShopName);

    printf("Enter quantity: ");
    scanf("%d", &quantity);

    for (int i = 0; i < totalcomputer; i++) {
        if (strcmp(computer[i].name, ShopName) == 0) {
            if (computer[i].quantity >= quantity) {
                computer[i].quantity -= quantity;
                printf("Sale completed successfully.\n");
                return;
            } else {
                printf("Insufficient quantity. Sale cannot be completed.\n");
                return;
            }
        }
    }

    printf("Shop not found in the inventory.\n");
}

int main() {
    int choice;

    while(choice != 4) {
        printf("========= Rodro's Computer Shop =========\n");
        printf("1. Add new computer\n");
        printf("2. Display \n");
        printf("3. Sale\n");
        printf("4. Exit\n");
        printf("Enter your choice: ");
        scanf("%d", &choice);

        switch (choice) {
            case 1:
                add_computer();
                break;
            case 2:
                display();
                break;

                Sale();
                break;
            case 4:
                printf("Thank you for using the system!\n");
                break;
            default:
                printf("Invalid choice. Please try again.\n");
                break;
        }

        printf("\n");
����}
}
